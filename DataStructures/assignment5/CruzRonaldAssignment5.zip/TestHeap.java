package assignment5;
import java.util.Random;
/**
 * 
 * @author Ronald Cruz
 *
 *
 */
public class TestHeap {

	public static void main(String[] args) {
		/**
		 * Created a heap with some initial values and more are added. It was stored as temp.
		 */
		int [] heap = {100, 96, 3, 21, 15, 26, 36, 12, 95, 55};
		BoundedTernaryMinHeap temp = new BoundedTernaryMinHeap(heap);
		Random randomInt = new Random();
		
		//A random set of values from 0 - 500 are added to it anywhere from 0 to 900 times.
		for (int i = 0; i < randomInt.nextInt(900); i++)
			temp.addElement(randomInt.nextInt(500));
		
		//All integers smaller than 100 are returned in a list.
		System.out.println("Here are all the values less than 150: \n");
		int[] small = temp.getSmallerThanK(150);
		for (int i = 0; i < small.length; i++){
			if (small[i] != 0)
			System.out.print(small[i] + " ");
		}
		System.out.println("\n");
		//Prints all the values of the list in order from least to greatest.
		System.out.println("Here are all the values from least to greatest in the heap: \n");
		while (!temp.isEmpty()){
			System.out.println(temp.getMin());
			temp.removeMin();
		}
		System.out.println();

		}

}
